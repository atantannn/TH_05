﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home_Week_05__toko_baju_
{
    public partial class Fashion_Shop : Form
    {
        DataTable dtproduct;
        DataTable dtcategory;
        DataTable dtproducttampil;
        DataRow row; //buat tambah roww
        string idprod;
        public Fashion_Shop()
        {
            InitializeComponent();
            dtproduct = new DataTable();
            dtcategory = new DataTable();
            dtproducttampil = new DataTable();
            cb_filterkategori.Enabled = false;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtproduct.Columns.Add("ID Product");
            dtproduct.Columns.Add("Nama Product");
            dtproduct.Columns.Add("Harga");
            dtproduct.Columns.Add("Stock");
            dtproduct.Columns.Add("ID Category");
            dtproduct.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtproduct.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtproduct.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtproduct.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtproduct.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtproduct.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtproduct.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dtproduct.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            datagridview_produktampil.DataSource = dtproduct;

            dtcategory.Columns.Add("ID Category");
            dtcategory.Columns.Add("Nama Category");
            dtcategory.Rows.Add("C1", "Jas");
            dtcategory.Rows.Add("C2", "T-Shirt");
            dtcategory.Rows.Add("C3", "Rok");
            dtcategory.Rows.Add("C4", "Celana");
            dtcategory.Rows.Add("C5", "Cawat");

            datagridview_category.DataSource = dtcategory;
            dtproducttampil = dtproduct.Copy();

            cb_filterkategori.Items.Clear();
            foreach (DataGridViewRow row in datagridview_category.Rows)
            {
                cb_filterkategori.Items.Add(row.Cells["Nama Category"].Value.ToString());
            }

            foreach (DataGridViewRow row in datagridview_category.Rows)
            {
                cb_pilihkategori.Items.Add(row.Cells[1].Value.ToString());
            }


        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            cb_filterkategori.Enabled = true;
            
        }

        private void btn_removeproduct_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dtproduct.Rows.Count; i++)
            {
                if (dtproduct.Rows[i][0].ToString() == datagridview_produktampil.CurrentRow.Cells[0].Value.ToString())
                {
                    dtproduct.Rows.RemoveAt(i);
                }
            }
            txtbox_nama.Clear();
            txtbox_harga.Clear();
            txtbox_stock.Clear();
            cb_pilihkategori.SelectedIndex = -1;
        }

        private void btn_addproduct_Click(object sender, EventArgs e)
        {
            if (txtbox_nama.Text == "" || txtbox_stock.Text == "" || txtbox_harga.Text == "")
            {
                MessageBox.Show("Masukkan semua details dengan lengkap ya");
            }
            else if (cb_pilihkategori.SelectedItem == null)
            {
                MessageBox.Show("Pilih kategorinya dulu ya");
            }
            else
            {
                foreach (DataRow rowcategory in dtcategory.Rows)
                {
                    if (rowcategory[1].ToString() == cb_pilihkategori.SelectedItem.ToString())
                    {
                        row = dtproduct.NewRow();
                        row[0] = IDProductTampil();
                        row[1] = txtbox_nama.Text;
                        row[2] = txtbox_harga.Text;
                        row[3] = txtbox_stock.Text;
                        row[4] = rowcategory[0].ToString();
                        dtproduct.Rows.Add(row);
                    }
                }

            }
            txtbox_nama.Clear();
            txtbox_harga.Clear();
            txtbox_stock.Clear();
            cb_pilihkategori.SelectedIndex = -1;

        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            btn_filter.Enabled = false;
            datagridview_produktampil.DataSource = dtproduct;
        }

        private void btn_addcategory_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (txtbox_addcategory.Text == "")
            {
                MessageBox.Show("Masukkan nama kategori terlebih dahulu");
            }
            else
            {
                bool sudahada = true;
                foreach (DataRow row in dtcategory.Rows)
                {
                    if (txtbox_addcategory.Text == row[1].ToString())
                    {
                        sudahada = false;
                    }
                }
                if (!sudahada)
                {
                    MessageBox.Show("Category sudah ada.");
                }
                else
                {
                    for (int i = 0; i < dtcategory.Rows.Count; i++)
                    {
                        int nomoridcat = Convert.ToInt32(dtcategory.Rows[i][0].ToString().Substring(1));
                        if (nomoridcat >= count)
                        {
                            count = nomoridcat;
                        }
                    }
                    row = dtcategory.NewRow();
                    row[0] = "C" + (count + 1);
                    row[1] = txtbox_addcategory.Text;
                    dtcategory.Rows.Add(row);
                }
            }
            cb_filterkategori.Items.Clear();
            foreach (DataGridViewRow row in datagridview_category.Rows)
            {
                cb_filterkategori.Items.Add(row.Cells["Nama Category"].Value.ToString());
            }
            cb_pilihkategori.Items.Clear();
            foreach (DataGridViewRow row in datagridview_category.Rows)
            {
                cb_pilihkategori.Items.Add(row.Cells[1].Value.ToString());
            }
            txtbox_addcategory.Clear();

        }

        private void txtbox_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            string validChars = "0123456789";
            if (!validChars.Contains(e.KeyChar.ToString()) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbox_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            string validChars = "0123456789.";
            if (!validChars.Contains(e.KeyChar.ToString()) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void datagridview_produktampil_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            txtbox_nama.Text = datagridview_produktampil.CurrentRow.Cells[1].Value.ToString();
            txtbox_harga.Text = datagridview_produktampil.CurrentRow.Cells[2].Value.ToString();
            txtbox_stock.Text = datagridview_produktampil.CurrentRow.Cells[3].Value.ToString();
            cb_pilihkategori.SelectedValue = datagridview_produktampil.CurrentRow.Cells[4].Value.ToString();
            foreach (DataRow row in dtcategory.Rows)
            {
                if (row[0].ToString() == datagridview_produktampil.CurrentRow.Cells[4].Value.ToString())
                {
                    cb_pilihkategori.Text = row[1].ToString();
                }
            }

        }
        private string IDProductTampil()
        {
            int id = 0;
            for (int i = 0; i < dtproduct.Rows.Count; i++)
            {
                if (dtproduct.Rows[i][0].ToString().Substring(0, 1) == txtbox_nama.Text.ToString().Substring(0, 1))
                {
                    id++;
                }
            }
            if (id <= 99)
            {
                if (txtbox_nama.Text.Length > 0)
                {
                    idprod = txtbox_nama.Text.ToString().Substring(0, 1).ToUpper() + "00" + (id + 1);
                }

            }
            else
            {
                idprod = txtbox_nama.Text.ToString().Substring(0, 1).ToUpper() + (id + 1);
            }
            return idprod;
        }

        private void btn_removecategory_Click(object sender, EventArgs e)
        {
            string deletedcategory = datagridview_category.CurrentRow.Cells[0].Value.ToString();
            for (int i = dtcategory.Rows.Count - 1; i >= 0; i--)
            {
                if (dtcategory.Rows[i][0].ToString() == deletedcategory)
                {
                    dtcategory.Rows.RemoveAt(i);
                }
            }
            for (int i = dtproduct.Rows.Count - 1; i >= 0; i--)
            {
                if (dtproduct.Rows[i][4].ToString() == deletedcategory)
                {
                    dtproduct.Rows.RemoveAt(i);
                }
            }
            cb_filterkategori.Items.Clear();
            foreach (DataGridViewRow row in datagridview_category.Rows)
            {
                cb_filterkategori.Items.Add(row.Cells["Nama Category"].Value.ToString());
            }
            cb_pilihkategori.Items.Clear();
            foreach (DataGridViewRow row in datagridview_category.Rows)
            {
                cb_pilihkategori.Items.Add(row.Cells[1].Value.ToString());
            }
            txtbox_addcategory.Clear();
            txtbox_nama.Clear();
            txtbox_harga.Clear();
            txtbox_stock.Clear();
            cb_pilihkategori.SelectedIndex = -1;

        }

        private void datagridview_category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtbox_addcategory.Text = datagridview_category.CurrentRow.Cells[1].Value.ToString();
        }

        private void btn_editproduct_Click(object sender, EventArgs e)
        {
            if (txtbox_nama.Text == "" || txtbox_stock.Text == "" || txtbox_harga.Text == "")
            {
                MessageBox.Show("Pilih produk yang mau di edit dulu");
            }
            else if (cb_pilihkategori.SelectedItem == null)
            {
                MessageBox.Show("Pilih kategorinya dulu ya");
            }
            else
            {
                string editidprod = datagridview_produktampil.CurrentRow.Cells[0].Value.ToString();
                int index = -1;
                for (int i = 0; i < dtproduct.Rows.Count; i++)
                {
                    if (dtproduct.Rows[i][0].ToString() == editidprod)
                    {
                        index = i;
                        break;
                    }
                }

                if (index != -1)
                {
                    DataRow row = dtproduct.Rows[index];
                    row[1] = txtbox_nama.Text;
                    row[2] = txtbox_harga.Text;
                    row[3] = txtbox_stock.Text;

                    int stock = Convert.ToInt32(row[3]);
                    if (stock == 0)
                    {
                        
                        dtproduct.Rows.RemoveAt(index);
                    }
                    string selectedCategoryId = "";
                    foreach (DataRow categoryRow in dtcategory.Rows)
                    {
                        if (categoryRow[1].ToString() == cb_pilihkategori.SelectedItem.ToString())
                        {
                            selectedCategoryId = categoryRow[0].ToString();
                            break;
                        }
                    }
                    row[4] = selectedCategoryId;
                    datagridview_produktampil.DataSource = null;
                    datagridview_produktampil.DataSource = dtproduct;
                }
                txtbox_nama.Clear();
                txtbox_harga.Clear();
                txtbox_stock.Clear();
                cb_pilihkategori.SelectedIndex = -1;
                
                
            }

        }

        private void cb_filterkategori_SelectedIndexChanged(object sender, EventArgs e)
        {
            string kategoriDipilih = cb_filterkategori.SelectedItem.ToString();

            if (!string.IsNullOrEmpty(kategoriDipilih))
            {
                
                dtproducttampil.Rows.Clear();

                
                foreach (DataRow produkRow in dtproduct.Rows)
                {
                    
                    string idKategoriProduk = produkRow["ID Category"].ToString();
                    foreach (DataRow kategoriRow in dtcategory.Rows)
                    {
                        
                        if (kategoriRow["Nama Category"].ToString() == kategoriDipilih)
                        {
                            
                            if (idKategoriProduk == kategoriRow["ID Category"].ToString())
                            {
                                DataRow newrow = dtproducttampil.NewRow();
                                newrow["ID Product"] = produkRow[0];
                                newrow["Nama Product"] = produkRow[1];
                                newrow["Harga"] = produkRow[2];
                                newrow["Stock"] = produkRow[3];
                                newrow["ID Category"] = produkRow[4];
                                dtproducttampil.Rows.Add(newrow);
                                break; 
                            }
                        }
                    }
                }
                datagridview_produktampil.DataSource = dtproducttampil;
            }
        }
        
    }
}
