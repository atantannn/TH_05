﻿namespace Take_Home_Week_05__toko_baju_
{
    partial class Fashion_Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.datagridview_produktampil = new System.Windows.Forms.DataGridView();
            this.lb_category = new System.Windows.Forms.Label();
            this.lb_product = new System.Windows.Forms.Label();
            this.btn_All = new System.Windows.Forms.Button();
            this.datagridview_category = new System.Windows.Forms.DataGridView();
            this.btn_filter = new System.Windows.Forms.Button();
            this.cb_filterkategori = new System.Windows.Forms.ComboBox();
            this.lb_details = new System.Windows.Forms.Label();
            this.lb_nama = new System.Windows.Forms.Label();
            this.lb_kategori = new System.Windows.Forms.Label();
            this.lb_harga = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtbox_nama = new System.Windows.Forms.TextBox();
            this.cb_pilihkategori = new System.Windows.Forms.ComboBox();
            this.txtbox_harga = new System.Windows.Forms.TextBox();
            this.txtbox_stock = new System.Windows.Forms.TextBox();
            this.lb_namacategory = new System.Windows.Forms.Label();
            this.txtbox_addcategory = new System.Windows.Forms.TextBox();
            this.btn_addproduct = new System.Windows.Forms.Button();
            this.btn_editproduct = new System.Windows.Forms.Button();
            this.btn_removeproduct = new System.Windows.Forms.Button();
            this.btn_addcategory = new System.Windows.Forms.Button();
            this.btn_removecategory = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.datagridview_produktampil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagridview_category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // datagridview_produktampil
            // 
            this.datagridview_produktampil.AllowUserToAddRows = false;
            this.datagridview_produktampil.AllowUserToDeleteRows = false;
            this.datagridview_produktampil.AllowUserToOrderColumns = true;
            this.datagridview_produktampil.AllowUserToResizeRows = false;
            this.datagridview_produktampil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridview_produktampil.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.datagridview_produktampil.Location = new System.Drawing.Point(26, 69);
            this.datagridview_produktampil.Name = "datagridview_produktampil";
            this.datagridview_produktampil.RowHeadersVisible = false;
            this.datagridview_produktampil.RowHeadersWidth = 51;
            this.datagridview_produktampil.RowTemplate.Height = 24;
            this.datagridview_produktampil.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagridview_produktampil.Size = new System.Drawing.Size(670, 347);
            this.datagridview_produktampil.TabIndex = 0;
            this.datagridview_produktampil.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridview_produktampil_CellClick);
            // 
            // lb_category
            // 
            this.lb_category.AutoSize = true;
            this.lb_category.Font = new System.Drawing.Font("Britannic Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_category.Location = new System.Drawing.Point(831, 19);
            this.lb_category.Name = "lb_category";
            this.lb_category.Size = new System.Drawing.Size(133, 33);
            this.lb_category.TabIndex = 1;
            this.lb_category.Text = "Category";
            // 
            // lb_product
            // 
            this.lb_product.AutoSize = true;
            this.lb_product.Font = new System.Drawing.Font("Britannic Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_product.Location = new System.Drawing.Point(21, 16);
            this.lb_product.Name = "lb_product";
            this.lb_product.Size = new System.Drawing.Size(120, 33);
            this.lb_product.TabIndex = 2;
            this.lb_product.Text = "Product";
            // 
            // btn_All
            // 
            this.btn_All.Location = new System.Drawing.Point(408, 30);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(52, 23);
            this.btn_All.TabIndex = 3;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = true;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // datagridview_category
            // 
            this.datagridview_category.AllowUserToAddRows = false;
            this.datagridview_category.AllowUserToDeleteRows = false;
            this.datagridview_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridview_category.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.datagridview_category.Location = new System.Drawing.Point(826, 69);
            this.datagridview_category.Name = "datagridview_category";
            this.datagridview_category.RowHeadersVisible = false;
            this.datagridview_category.RowHeadersWidth = 51;
            this.datagridview_category.RowTemplate.Height = 24;
            this.datagridview_category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagridview_category.Size = new System.Drawing.Size(261, 274);
            this.datagridview_category.TabIndex = 4;
            this.datagridview_category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridview_category_CellClick);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(467, 31);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(67, 23);
            this.btn_filter.TabIndex = 5;
            this.btn_filter.Text = "Filter :";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // cb_filterkategori
            // 
            this.cb_filterkategori.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_filterkategori.FormattingEnabled = true;
            this.cb_filterkategori.Location = new System.Drawing.Point(540, 30);
            this.cb_filterkategori.Name = "cb_filterkategori";
            this.cb_filterkategori.Size = new System.Drawing.Size(156, 24);
            this.cb_filterkategori.TabIndex = 6;
            this.cb_filterkategori.SelectedIndexChanged += new System.EventHandler(this.cb_filterkategori_SelectedIndexChanged);
            // 
            // lb_details
            // 
            this.lb_details.AutoSize = true;
            this.lb_details.Font = new System.Drawing.Font("Britannic Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_details.Location = new System.Drawing.Point(21, 442);
            this.lb_details.Name = "lb_details";
            this.lb_details.Size = new System.Drawing.Size(106, 33);
            this.lb_details.TabIndex = 7;
            this.lb_details.Text = "Details";
            // 
            // lb_nama
            // 
            this.lb_nama.AutoSize = true;
            this.lb_nama.Location = new System.Drawing.Point(43, 510);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(50, 16);
            this.lb_nama.TabIndex = 8;
            this.lb_nama.Text = "Nama :";
            // 
            // lb_kategori
            // 
            this.lb_kategori.AutoSize = true;
            this.lb_kategori.Location = new System.Drawing.Point(25, 542);
            this.lb_kategori.Name = "lb_kategori";
            this.lb_kategori.Size = new System.Drawing.Size(68, 16);
            this.lb_kategori.TabIndex = 9;
            this.lb_kategori.Text = "Category :";
            // 
            // lb_harga
            // 
            this.lb_harga.AutoSize = true;
            this.lb_harga.Location = new System.Drawing.Point(42, 574);
            this.lb_harga.Name = "lb_harga";
            this.lb_harga.Size = new System.Drawing.Size(51, 16);
            this.lb_harga.TabIndex = 10;
            this.lb_harga.Text = "Harga :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 608);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 16);
            this.label1.TabIndex = 11;
            this.label1.Text = "Stock :";
            // 
            // txtbox_nama
            // 
            this.txtbox_nama.Location = new System.Drawing.Point(98, 510);
            this.txtbox_nama.Name = "txtbox_nama";
            this.txtbox_nama.Size = new System.Drawing.Size(282, 22);
            this.txtbox_nama.TabIndex = 12;
            // 
            // cb_pilihkategori
            // 
            this.cb_pilihkategori.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_pilihkategori.FormattingEnabled = true;
            this.cb_pilihkategori.Location = new System.Drawing.Point(99, 540);
            this.cb_pilihkategori.Name = "cb_pilihkategori";
            this.cb_pilihkategori.Size = new System.Drawing.Size(115, 24);
            this.cb_pilihkategori.TabIndex = 13;
            // 
            // txtbox_harga
            // 
            this.txtbox_harga.Location = new System.Drawing.Point(99, 573);
            this.txtbox_harga.Name = "txtbox_harga";
            this.txtbox_harga.Size = new System.Drawing.Size(115, 22);
            this.txtbox_harga.TabIndex = 14;
            this.txtbox_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbox_harga_KeyPress);
            // 
            // txtbox_stock
            // 
            this.txtbox_stock.Location = new System.Drawing.Point(98, 608);
            this.txtbox_stock.Name = "txtbox_stock";
            this.txtbox_stock.Size = new System.Drawing.Size(115, 22);
            this.txtbox_stock.TabIndex = 15;
            this.txtbox_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbox_stock_KeyPress);
            // 
            // lb_namacategory
            // 
            this.lb_namacategory.AutoSize = true;
            this.lb_namacategory.Location = new System.Drawing.Point(825, 375);
            this.lb_namacategory.Name = "lb_namacategory";
            this.lb_namacategory.Size = new System.Drawing.Size(50, 16);
            this.lb_namacategory.TabIndex = 16;
            this.lb_namacategory.Text = "Nama :";
            // 
            // txtbox_addcategory
            // 
            this.txtbox_addcategory.Location = new System.Drawing.Point(881, 372);
            this.txtbox_addcategory.Name = "txtbox_addcategory";
            this.txtbox_addcategory.Size = new System.Drawing.Size(206, 22);
            this.txtbox_addcategory.TabIndex = 17;
            // 
            // btn_addproduct
            // 
            this.btn_addproduct.BackColor = System.Drawing.Color.LightYellow;
            this.btn_addproduct.Location = new System.Drawing.Point(239, 567);
            this.btn_addproduct.Name = "btn_addproduct";
            this.btn_addproduct.Size = new System.Drawing.Size(75, 50);
            this.btn_addproduct.TabIndex = 18;
            this.btn_addproduct.Text = "Add Product";
            this.btn_addproduct.UseVisualStyleBackColor = false;
            this.btn_addproduct.Click += new System.EventHandler(this.btn_addproduct_Click);
            // 
            // btn_editproduct
            // 
            this.btn_editproduct.BackColor = System.Drawing.Color.GreenYellow;
            this.btn_editproduct.Location = new System.Drawing.Point(312, 567);
            this.btn_editproduct.Name = "btn_editproduct";
            this.btn_editproduct.Size = new System.Drawing.Size(75, 50);
            this.btn_editproduct.TabIndex = 19;
            this.btn_editproduct.Text = "Edit Product";
            this.btn_editproduct.UseVisualStyleBackColor = false;
            this.btn_editproduct.Click += new System.EventHandler(this.btn_editproduct_Click);
            // 
            // btn_removeproduct
            // 
            this.btn_removeproduct.BackColor = System.Drawing.Color.LightCoral;
            this.btn_removeproduct.Location = new System.Drawing.Point(385, 567);
            this.btn_removeproduct.Name = "btn_removeproduct";
            this.btn_removeproduct.Size = new System.Drawing.Size(75, 50);
            this.btn_removeproduct.TabIndex = 20;
            this.btn_removeproduct.Text = "Remove Product";
            this.btn_removeproduct.UseVisualStyleBackColor = false;
            this.btn_removeproduct.Click += new System.EventHandler(this.btn_removeproduct_Click);
            // 
            // btn_addcategory
            // 
            this.btn_addcategory.BackColor = System.Drawing.Color.LightYellow;
            this.btn_addcategory.Location = new System.Drawing.Point(910, 400);
            this.btn_addcategory.Name = "btn_addcategory";
            this.btn_addcategory.Size = new System.Drawing.Size(76, 61);
            this.btn_addcategory.TabIndex = 21;
            this.btn_addcategory.Text = "Add Category";
            this.btn_addcategory.UseVisualStyleBackColor = false;
            this.btn_addcategory.Click += new System.EventHandler(this.btn_addcategory_Click);
            // 
            // btn_removecategory
            // 
            this.btn_removecategory.BackColor = System.Drawing.Color.LightCoral;
            this.btn_removecategory.Location = new System.Drawing.Point(988, 400);
            this.btn_removecategory.Name = "btn_removecategory";
            this.btn_removecategory.Size = new System.Drawing.Size(80, 61);
            this.btn_removecategory.TabIndex = 22;
            this.btn_removecategory.Text = "Remove Category";
            this.btn_removecategory.UseVisualStyleBackColor = false;
            this.btn_removecategory.Click += new System.EventHandler(this.btn_removecategory_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Take_Home_Week_05__toko_baju_.Properties.Resources.jeno_nct_meme_reaction;
            this.pictureBox1.Location = new System.Drawing.Point(831, 496);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(256, 260);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // Fashion_Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(1245, 794);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_removecategory);
            this.Controls.Add(this.btn_addcategory);
            this.Controls.Add(this.btn_removeproduct);
            this.Controls.Add(this.btn_editproduct);
            this.Controls.Add(this.btn_addproduct);
            this.Controls.Add(this.txtbox_addcategory);
            this.Controls.Add(this.lb_namacategory);
            this.Controls.Add(this.txtbox_stock);
            this.Controls.Add(this.txtbox_harga);
            this.Controls.Add(this.cb_pilihkategori);
            this.Controls.Add(this.txtbox_nama);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_harga);
            this.Controls.Add(this.lb_kategori);
            this.Controls.Add(this.lb_nama);
            this.Controls.Add(this.lb_details);
            this.Controls.Add(this.cb_filterkategori);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.datagridview_category);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.lb_product);
            this.Controls.Add(this.lb_category);
            this.Controls.Add(this.datagridview_produktampil);
            this.Name = "Fashion_Shop";
            this.Text = "Blink Shop";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridview_produktampil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagridview_category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView datagridview_produktampil;
        private System.Windows.Forms.Label lb_category;
        private System.Windows.Forms.Label lb_product;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.DataGridView datagridview_category;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox cb_filterkategori;
        private System.Windows.Forms.Label lb_details;
        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.Label lb_kategori;
        private System.Windows.Forms.Label lb_harga;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbox_nama;
        private System.Windows.Forms.ComboBox cb_pilihkategori;
        private System.Windows.Forms.TextBox txtbox_harga;
        private System.Windows.Forms.TextBox txtbox_stock;
        private System.Windows.Forms.Label lb_namacategory;
        private System.Windows.Forms.TextBox txtbox_addcategory;
        private System.Windows.Forms.Button btn_addproduct;
        private System.Windows.Forms.Button btn_editproduct;
        private System.Windows.Forms.Button btn_removeproduct;
        private System.Windows.Forms.Button btn_addcategory;
        private System.Windows.Forms.Button btn_removecategory;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

